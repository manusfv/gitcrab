# GitCrab / Three visual identities

Three complete, alternative identity directions for the same desktop Git client. All retain the requested black, charcoal and electric blue palette. The alternatives differ in symbol construction, typography, composition, graphic language and voice.

Start with `comparison.png`, then open the `identity-board.png` in each direction folder. Each board shows the logo system, typography, exact palette, a desktop Git-client application, a launch graphic and actual-size app/toolbar icons.

## 01 / Forkshell

**Character:** bold, direct and in control.

The raised pincers, planted legs and branching counter make the most literal crab of the three. Segoe UI Bold gives the wordmark weight and presence. High-contrast black surfaces, generous blue accents and thick diagonal strokes carry the symbol's energy into other materials.

**Brand line:** Own your next commit.

Use short, active statements. Lead compositions with one large headline or logo, then one decisive graphic. Keep blue concentrated on the right claw, selected actions and directional strokes. The product sample uses a dark interface with clear blue selections.

**Type:** Segoe UI Bold for brand headings and wordmark; Segoe UI Regular for body/UI; Consolas for code, hashes and labels.

**Palette:** ink `#111318`, charcoal `#292D36`, electric blue `#668BFF`, canvas `#F4F5F7`, white `#FFFFFF`.

## 02 / Branchline

**Character:** open, calm and connected.

An asymmetric path joins two terminal nodes to the crab's body. Segoe UI Regular and open layouts make the brand feel approachable. Fine curved paths, clear terminal circles and generous white space become the supporting graphic language.

**Brand line:** Every branch. A clear path.

Use calm, concrete language that helps people understand the next step. Give diagrams and content room to breathe. Keep decorative paths to one or two per composition, ending them in clear nodes. The product sample uses a light interface with restrained blue emphasis.

**Type:** Segoe UI Regular for brand headings and wordmark; Segoe UI Regular/Semibold for UI hierarchy; Consolas for code, hashes and labels.

**Palette:** ink `#111318`, charcoal `#292D36`, electric blue `#668BFF`, canvas `#F6F8FC`, white `#FFFFFF`.

## 03 / Splitclaw

**Character:** precise, modular and assured.

Five solid geometric pieces create an architectural crab. The gaps below the central diamond suggest branching. Bahnschrift's DIN-derived forms reinforce the geometry. Oversized crops of the pincers and carapace create a recognizable graphic system on a quiet alignment grid.

**Brand line:** Precision in every change.

Use measured, compact language. Align elements to a consistent grid. Leave deliberate space around each module; do not pack multiple cropped symbols together. Grids should be subtle and used in presentation or marketing surfaces, while product screens remain visually quiet.

**Type:** Bahnschrift Regular for brand headings and wordmark; Segoe UI Regular/Semibold for UI; Consolas for code, hashes and labels.

**Palette:** ink `#111318`, charcoal `#292D36`, electric blue `#668BFF`, canvas `#F3F4F6`, white `#FFFFFF`.

## Shared rules

- Use the symbol at 16 px and above; prefer a monochrome toolbar export at the smallest size.
- Use full lockups at 140 px wide and above; switch to the standalone symbol when space is tight.
- Keep at least 16 design units of clear space around a 128-unit-wide symbol. Toolbar assets have intentionally tighter framing.
- Preserve the original aspect ratio, open counters and negative spaces. Do not add outlines, faces, gradients, shadows or additional accent colors.
- Use ink-colored text on blue buttons and white text on dark surfaces. Keep blue primarily for emphasis, selection and graph paths.
- Use an 8 px spacing rhythm in the UI. The supplied screens are identity applications, not changes to the working app.
- Keep each direction coherent: use its wordmark, motif and type together.

## Files in each direction

- `identity-board.png`: complete visual identity board.
- `symbol-{color,dark,mono,white}.{svg,png}`: transparent standalone artwork.
- `lockup-{color,dark,mono,white}.{svg,png}`: transparent horizontal wordmark lockups.
- `app-icon.svg` and `app-icon-{16,24,32,64,128,256,512,1024}.png`: app assets.
- `toolbar-{color,mono,white}-{16,24,32}.png`: actual-size transparent toolbar icons.
- `graphic-language.svg` / `.png`: reusable supporting graphic.
- `launch-card.png`: standalone campaign application.
- `product-application.png`: desktop UI application.
- `tokens.json`: exact palette, typography and spacing values.

SVG wordmarks are outlined, so they display without installed fonts. The master artwork uses flat shapes and exact fills; transparent PNGs preserve alpha. Font binaries are not bundled. `build-identities.ps1` rebuilds the assets on Windows using System.Drawing and the installed fonts. These systems extend the three concepts from the earlier image-generated exploration with editable vector masters.

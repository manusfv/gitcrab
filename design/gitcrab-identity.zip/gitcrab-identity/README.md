# GitCrab / Splitclaw

Three directions were explored: Forkshell, Branchline and Splitclaw. Splitclaw was selected for its compact architectural silhouette and open negative space. Two bracket-like pincers frame a faceted carapace; the space below it divides into a subtle branch. A single blue claw supplies recognition without making color essential.

## Artwork

- `concept-exploration.png`: three initial visual directions, generated with the built-in image tool.
- `identity-board.png`: final design comparison, variants and app/toolbar previews.
- `symbol-color.svg` / `.png`: transparent primary symbol.
- `symbol-dark.svg` / `.png`: white and electric blue for dark backgrounds.
- `symbol-mono.svg` / `.png`: one-color dark artwork.
- `symbol-white.svg` / `.png`: one-color reversed artwork.
- `lockup-*.svg` / `.png`: corresponding transparent symbol and wordmark lockups.
- `app-icon.svg` and `app-icon-{16,24,32,64,128,256,512,1024}.png`: desktop app assets.
- `toolbar-{color,mono,white}-{16,24,32}.png`: actual-size transparent toolbar assets.

The final production geometry was redrawn as five solid vector paths following the selected image exploration. All PNG exports are rendered from that geometry; they contain no gradients, shadows or textures. The primary ink is `#111318`, charcoal is `#292D36`, accent is `#668BFF`, and reverse ink is white. SVGs have no external dependencies.

The wordmark uses Bahnschrift Regular, whose DIN-derived forms balance the angular symbol with a clear engineering character. All distributed SVG wordmarks are outlined, so the font need not be installed to display them.

## Usage

Use the symbol without a tile in toolbars; use the charcoal tile for desktop app surfaces. Prefer the monochrome or white toolbar export at 16 px. Keep a minimum clear margin of 16 units around the 128-unit-wide symbol, except in the intentionally tight toolbar exports. Do not close the center gap, add facial features, or assign different colors to the lower shell pieces.

The small icons are rendered at their stated pixel dimensions. View them at 100% display scaling for pixel-size inspection. The identity board includes true 16, 24 and 32 px toolbar symbols inside its 1600 px canvas.

Run `build-assets.ps1` in Windows PowerShell to regenerate the vector and raster assets using System.Drawing and the installed Bahnschrift font. The generated exploration is retained as a design reference; the final vector artwork is the production master.


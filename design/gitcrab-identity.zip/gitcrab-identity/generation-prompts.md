# Exploration prompts

Mode: built-in image generation. The images informed the final geometric vector artwork. Production assets are rendered from `build-assets.ps1`.

## Three concepts

Use case: logo-brand.
Create a polished professional identity exploration presentation for GitCrab, a modern desktop Git client. Landscape design board, white background, restrained Swiss editorial typography, three equal-width columns separated only by generous whitespace. Exactly THREE genuinely different original geometric crab symbols. Large black silhouettes make the concepts easy to compare. Each mark appears once large and once smaller in the accent version underneath. Very little text, only header "GitCrab / Identity exploration" and column labels below.
01 "Forkshell": bold compact bilateral crab silhouette, a low faceted carapace, two powerful upward pincer arms built as bifurcating angular forms. A fork-shaped negative space at the center subtly suggests Git branching. No circular eyes. Confident filled masses and clean open counters; one upper claw element can be electric blue.
02 "Branchline": an asymmetric, striking continuous thick geometric path that forms a crab body and two upward forked claws, with just two integrated terminal nodes. More open and airy than 01, clear graph logic without being a diagram. No eyes. One terminal is electric blue.
03 "Splitclaw": an abstract architectural crab built from three interlocking solid wedge forms and mirrored bracket-like pincers. Wide, angular, precise, sculptural silhouette. The branching idea is carried by the gap where two pieces diverge. Visibly different construction from 01 and 02.
All three must remain recognizably crab inspired with lifted pincers, not butterflies, horns or an octopus. Avoid cartoon mascots, faces, eyes, GitHub/octocat silhouettes, GitKraken motifs, generic monograms, circles around the marks, rounded-square containers, tiny appendages, gradients, glow, shadows, textures, mockup perspective, stock clipart. Flat only. Palette black #111318, charcoal #292D36, accent exact #668BFF. Minimal, distinctive, clever. Equal optical scale across columns, huge clear margins. Do not add diagrams or explanatory copy.

## Selected symbol

Use case: logo-brand. Edit target: the concept exploration image in the preceding conversation.
Select ONLY concept 03 "Splitclaw" at the RIGHT of that image. Create the final standalone symbol isolated on a genuinely transparent background. Remove all other concepts, all text and all presentation elements.
Preserve the right-hand concept's exact distinctive construction: two angular open bracket-shaped pincers lifted above a central low diamond carapace, two bold lower geometric shell/leg masses angled outward. The negative space below the diamond forks into the center gap between the lower masses, a subtle Git branching reference without any drawn diagram. Five bold disconnected geometric masses, no eyes, no face, no circular nodes, no extra appendages. Bilateral balanced geometry. Equal widths of key gaps and open pincer counters; generous enough for 16–32px. Make only tiny optical corrections to spacing, maintaining the original silhouette.
The symbol fills about 76% of the square canvas width with generous equal transparent margins, fully visible, centered optically. Flat solid fills only: main symbol near-black #111318, RIGHT UPPER PINCER entirely vivid electric blue #668BFF. Keep the other four geometric masses near-black. No gradients, glow, shadows, texture, outlines, checkerboard drawn into image, captions, wordmark, enclosing tile, or mockup. Knife-sharp geometric edges. This is an actual alpha-transparent production logo asset.

## Flat-color refinement

Use case: logo-brand. Edit the supplied standalone GitCrab logo. Change ONLY its surface rendering: remove ALL gradient shading, ALL lighting and ALL texture inside every shape. Preserve the exact silhouette, positions, five separate shapes, negative spaces and transparent background. It is a strict flat spot-color logo with exactly TWO ink colors: every dark shape must be uniformly #111318 and every pixel inside the upper-right claw must be uniformly #668BFF. Only edge antialiasing may vary; absolutely no change in color value across the interior of any shape. Print-vector aesthetic, solid opaque flat cutout shapes, no dimensional appearance at all. No border, background, text, new elements or checkerboard. Output an actual alpha-transparent PNG with the same square composition and generous margins.

## Initial presentation study

Use case: logo-brand. Professional final identity presentation board for GitCrab, a modern desktop Git client.
Use the supplied image as the EXACT logo reference. Preserve the five-part angular crab silhouette: mirrored upper bracket pincers, central diamond, two lower angular shell/leg pieces; upper-right claw blue. Do not redesign it or add details. Render the brand mark as perfectly flat solid spot colors, no gradient or shading.
Create an impeccably typeset wide landscape brand guideline sheet with generous whitespace, white background and calm grid. Top left tiny header "GITCRAB / SELECTED IDENTITY". Top right tiny label "03 / Splitclaw".
Main upper area: large horizontal lockup with reference symbol on the left and exact word "GitCrab" on right. Wordmark is carefully kerned contemporary geometric grotesk similar to Inter Tight Medium, confident medium weight, mixed case exactly GitCrab, near-black. No slogan.
Below, three evenly sized panels in a row: LIGHT with black-and-blue lockup on warm-white; DARK with white-and-blue lockup on flat charcoal #171A21; MONO with one-color near-black symbol and wordmark on white. Ensure ALL instances use the exact SAME silhouette as the reference.
Bottom row: left shows one large square desktop app icon with modest rounded corners, flat charcoal tile #171A21 and centered white-and-blue reference symbol; no shadow or gradient. Alongside the large icon, smaller 64px and 32px examples. Right shows a clean simple desktop Git app toolbar strip on white, with the reference crab symbol at three progressively small visual scales, labels "32", "24", "16". These are honest scale previews, avoid excessive detail. Lower right tiny swatches and exact text "#111318", "#292D36", "#668BFF".
Use only these labels, avoid long explanation. Perfect visual hierarchy, ample margins. No background graphics, texture, mockup perspective, artificial lighting, shadows or glow. Precise production graphic design, flat vector-like reproduction. Logo reference is invariant.
